# Exercise3 content
print('Exercise3 placeholder')