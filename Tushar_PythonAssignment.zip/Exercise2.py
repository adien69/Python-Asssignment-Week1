# Exercise2 content
print('Exercise2 placeholder')