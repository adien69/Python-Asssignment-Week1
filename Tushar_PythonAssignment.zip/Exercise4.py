# Exercise4 content
print('Exercise4 placeholder')