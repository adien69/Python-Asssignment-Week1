# Exercise1 content
print('Exercise1 placeholder')