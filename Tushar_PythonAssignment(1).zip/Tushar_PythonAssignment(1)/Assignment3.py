# ------------------------------------------------------------
# Exercise 3: Student Marks Processor
# ------------------------------------------------------------
# INTRODUCTION:
# This program reads student marks from a file, computes overall
# marks with weighting, assigns grades, creates a structured NumPy
# array, sorts data, writes output, and shows grade statistics.
# ------------------------------------------------------------

import numpy as np

def assign_grade(mark):
    if mark >= 85:
        return "A"
    elif mark >= 70:
        return "B"
    elif mark >= 55:
        return "C"
    elif mark >= 40:
        return "D"
    else:
        return "F"

def process_marks(input_file, output_file):
    try:
        # Read file
        data = np.genfromtxt(input_file, delimiter=',', dtype=str)

        # Prepare lists
        reg_no = []
        exam_marks = []
        coursework_marks = []
        overall_marks = []
        grades = []

        # Process each student
        for row in data:
            r, exam, course = row

            exam = float(exam)
            course = float(course)

            overall = exam * 0.6 + course * 0.4
            grade = assign_grade(overall)

            reg_no.append(r)
            exam_marks.append(exam)
            coursework_marks.append(course)
            overall_marks.append(overall)
            grades.append(grade)

        # Create structured NumPy array
        dtype = [('RegNo', 'U20'), ('Exam', float), ('Coursework', float), ('Overall', float), ('Grade', 'U2')]
        result = np.zeros(len(reg_no), dtype=dtype)

        result['RegNo'] = reg_no
        result['Exam'] = exam_marks
        result['Coursework'] = coursework_marks
        result['Overall'] = overall_marks
        result['Grade'] = grades

        # Sort by overall descending
        result = np.sort(result, order='Overall')[::-1]

        # Write output file
        np.savetxt(output_file, result, fmt='%s', delimiter=',', header="RegNo,Exam,Coursework,Overall,Grade", comments='')

        # Grade statistics
        print("\nGrade Distribution:")
        for g in ['A','B','C','D','F']:
            print(f"{g}: {grades.count(g)}")

    except Exception as e:
        print(f"Error: {e}")

# Run program
process_marks("student_marks.csv", "processed_results.csv")

# ------------------------------------------------------------
# CONCLUSION:
# This program processes student marks efficiently, generates grades,
# sorts them, saves results, and provides grade statistics reliably.
# ------------------------------------------------------------
