# ------------------------------------------------------------
# Exercise 4: Weather Data Fetcher & Analyzer
# ------------------------------------------------------------
# INTRODUCTION:
# This program fetches real-time weather data from OpenWeatherMap API,
# analyzes temperature, wind, and humidity, and logs results into a CSV.
# ------------------------------------------------------------

import requests
import csv

# Fetch weather data
def fetch_weather(city, api_key):
    try:
        url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
        response = requests.get(url)

        if response.status_code != 200:
            print("Error: Invalid city or API error!")
            return None

        return response.json()

    except requests.exceptions.RequestException:
        print("Network error! Check your connection.")
        return None

# Analyze weather
def analyze_weather(data):
    try:
        temp = data["main"]["temp"]
        wind = data["wind"]["speed"]
        humidity = data["main"]["humidity"]

        # Temperature category
        if temp <= 10:
            summary = "Cold (≤10°C)"
        elif temp <= 24:
            summary = "Mild (11–24°C)"
        else:
            summary = "Hot (≥25°C)"

        # Add warnings
        if wind > 10:
            summary += " | High wind alert!"
        if humidity > 80:
            summary += " | Humid conditions!"

        return summary

    except KeyError:
        return "Error: Missing weather data!"

# Log weather to file
def log_weather(city, filename):
    api_key = "ENTER_YOUR_API_KEY_HERE"

    weather = fetch_weather(city, api_key)

    if weather is None:
        return

    summary = analyze_weather(weather)

    # Append to CSV file
    with open(filename, "a", newline='') as file:
        writer = csv.writer(file)
        writer.writerow([city, weather["main"]["temp"], summary])

    print("\nWeather logged successfully!")

# Run program
city_name = input("Enter city name: ")
log_weather(city_name, "weather_log.csv")

# ------------------------------------------------------------
# CONCLUSION:
# This program fetches, analyzes, and logs real-world weather data
# while handling all errors and providing meaningful insights.
# ------------------------------------------------------------
