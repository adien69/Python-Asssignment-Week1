# ------------------------------------------------------------
# Exercise 2: Prime Number Generator
# ------------------------------------------------------------
# INTRODUCTION:
# This program accepts two positive integers, validates them,
# finds all prime numbers within the range, and prints them
# formatted (10 per line). Errors are handled gracefully.
# ------------------------------------------------------------

def is_prime(n):
    # Prime number check
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def prime_generator():
    try:
        # Input from user
        start = int(input("Enter start of range: "))
        end = int(input("Enter end of range: "))

        # Validate positive integers
        if start <= 0 or end <= 0:
            print("Error: Please enter positive integers only.")
            return

        # Validate range order
        if start > end:
            print("Error: Start of range cannot be greater than end.")
            return

        primes = []

        # Find primes in range
        for num in range(start, end + 1):
            if is_prime(num):
                primes.append(num)

        # Display primes, 10 per line
        print("\nPrime numbers:")
        for i in range(0, len(primes), 10):
            print(*primes[i:i+10])

    except ValueError:
        print("Error: Invalid input! Please enter integers only.")

# Run program
prime_generator()

# ------------------------------------------------------------
# CONCLUSION:
# This program efficiently generates prime numbers within a range
# while ensuring clean formatting and proper error handling.
# ------------------------------------------------------------
