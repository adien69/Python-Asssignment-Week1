# ------------------------------------------------------------
# Exercise 1: Age Calculator
# ------------------------------------------------------------
# INTRODUCTION:
# This program calculates the user's age from their birthdate.
# It validates the user's input, ensures the date is valid, converts
# formats, and handles all possible errors gracefully.
# ------------------------------------------------------------

from datetime import datetime

def calculate_age():
    try:
        # Ask user for input
        birth_input = input("Enter your birth date (mm/dd/yyyy): ")

        # Validate date format
        birth_date = datetime.strptime(birth_input, "%m/%d/%Y")

        # Get today's date
        today = datetime.today()

        # Calculate age
        age = today.year - birth_date.year

        # Adjust age if birthday hasn't occured this year yet
        if (today.month, today.day) < (birth_date.month, birth_date.day):
            age -= 1

        # Convert to European format
        european_format = birth_date.strftime("%d/%m/%Y")

        # Display results
        print(f"Your age is: {age} years")
        print(f"Your birthdate in European format: {european_format}")

    except ValueError:
        # Handle invalid date formats
        print("Error: Invalid date format! Please use mm/dd/yyyy")

# Run the program
calculate_age()

# ------------------------------------------------------------
# CONCLUSION:
# This program successfully validates user input, calculates age,
# converts date formats, and handles invalid inputs gracefully.
# ------------------------------------------------------------
